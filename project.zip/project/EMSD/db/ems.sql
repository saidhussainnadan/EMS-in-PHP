-- phpMyAdmin SQL Dump
-- version 3.5.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 12, 2017 at 09:31 AM
-- Server version: 5.5.25a
-- PHP Version: 5.4.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ems`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE IF NOT EXISTS `attendance` (
  `atten_id` int(11) NOT NULL AUTO_INCREMENT,
  `emp_regist_id` int(11) NOT NULL,
  `attendance` text NOT NULL,
  `dat` date NOT NULL,
  PRIMARY KEY (`atten_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`atten_id`, `emp_regist_id`, `attendance`, `dat`) VALUES
(3, 4, 'Absent', '2017-09-11'),
(4, 4, 'Present', '2017-09-12');

-- --------------------------------------------------------

--
-- Table structure for table `emp_regist`
--

CREATE TABLE IF NOT EXISTS `emp_regist` (
  `emp_regist_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `fname` text NOT NULL,
  `cnic` int(11) NOT NULL,
  `gender` text NOT NULL,
  `designation` text NOT NULL,
  `section` int(11) NOT NULL,
  `mobile` varchar(11) NOT NULL,
  `entry_date` date NOT NULL,
  `address` text NOT NULL,
  PRIMARY KEY (`emp_regist_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `emp_regist`
--

INSERT INTO `emp_regist` (`emp_regist_id`, `name`, `fname`, `cnic`, `gender`, `designation`, `section`, `mobile`, `entry_date`, `address`) VALUES
(1, 'Ali Noor', 'Ali', 2147483647, 'Male', 'CEO1', 5, '2069840147', '2017-04-07', '1188 Matthews1'),
(4, 'Ali', 'Ali11', 2147483647, 'Male', 'dfhd1', 5, '2069840147', '2017-04-13', '1188 Matthewsd'),
(5, 'Nasir', 'Ahmad', 17101, 'Male', 'CEO 7', 0, '2069840147', '2017-05-04', '1188 Matthews');

-- --------------------------------------------------------

--
-- Table structure for table `section`
--

CREATE TABLE IF NOT EXISTS `section` (
  `sec_id` int(11) NOT NULL AUTO_INCREMENT,
  `sec_name` text NOT NULL,
  PRIMARY KEY (`sec_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `section`
--

INSERT INTO `section` (`sec_id`, `sec_name`) VALUES
(5, 'Section111');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`) VALUES
(1, 'admin', 'admin');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
