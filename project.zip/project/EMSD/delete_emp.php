<?php
include("db/db.php");

$id=$_GET['delete'];

$sql="DELETE FROM emp_regist WHERE emp_regist_id='$id'";

$res=$conn->query($sql) or die ("not Deletd".mysql_error());

echo "<script>alert('Deleted Successfully!')</script>";
echo "<script>window.open('employees.php','_self')</script>";

?>