<?php session_start(); if(isset($_SESSION['username'])) { ?>

<?php include("header.php") ?>

    <div class="col-sm-9 col-lg-10 ">
      <div class="col-md-12 text-justify">
		<h3>Employee Details:</h3>
      </div>
	  
	  
	  <?php 
		
		if(isset($_GET['view'])) {
			$id=$_GET['view'];
		
			$sql="SELECT * 
			FROM  `emp_regist` 
			INNER JOIN section ON section.sec_id = emp_regist.section Where emp_regist_id = $id";
			$Q=mysql_query($sql);
			while($r=mysql_fetch_assoc($Q)) {
		
	?>
	  
	  <table class="table">
  <tbody>

    <tr>
      <td>Name:</td>
	  <td><?php echo $r['name']; ?></td>
    </tr>
	
	<tr>
      <td>F/Name:</td>
	  <td><?php echo $r['fname']; ?></td>
    </tr>
	
	<tr>
      <td>CNIC:</td>
	  <td><?php echo $r['cnic']; ?></td>
    </tr>
	
	<tr>
      <td>Mob#:</td>
	  <td><?php echo $r['mobile']; ?></td>
    </tr>
	
	<tr>
      <td>Gender:</td>
	  <td><?php echo $r['gender']; ?></td>
    </tr>
	
	<tr>
      <td>Designation:</td>
	  <td><?php echo $r['designation']; ?></td>
    </tr>
	
	<tr>
      <td>Section:</td>
	  <td><?php echo $r['sec_name']; ?></td>
    </tr>
	
	<tr>
      <td>Date of Entry:</td>
	  <td><?php echo $r['entry_date']; ?></td>
    </tr>
	
	<tr>
      <td>Address:</td>
	  <td><?php echo $r['address']; ?></td>
    </tr>
	
  </tbody>
</table>

<?php 
	}  
} 
?>
	  
    </div>
</div>
  
</div>

<div class="container" style="margin-bottom: 10px; background-color:#808080; border-radius: 0 0 10px 10px; padding-left: 39px;">
  <div class="row" style="padding-top: 8px;">
	<div class="col-med-12 text-center">
		<p>© PTCL MANAGEMENT SYSTEM</p>
	</div>
  </div>
</div>

</body>
<html>

<?php } else echo nl2br("You must be logged in! \n click <a href='index.php'>here</a> to login"); ?>