<?php session_start(); if(isset($_SESSION['username'])) { ?>

<?php include("header.php") ?>

    <div class="col-sm-9 col-lg-10 ">
      <div class="col-md-12 text-justify">
	  <h3>Change Password:</h3>
      	<form class="form-horizontal" method="post" action="">
	<div class="form-group">
      <label class="control-label col-sm-2" for="email">Old Password:</label>
      <div class="col-sm-6">
        <input type="text" name="oldpassword" class="form-control" />
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="pwd">New Password:</label>
      <div class="col-sm-6">          
        <input type="password" name="newpassword" class="form-control" required />
      </div>
    </div>
	<div class="form-group">
      <label class="control-label col-sm-2" for="pwd">Confirm Password</label>
      <div class="col-sm-6">          
        <input type="password" name="repeatnewpassword" class="form-control" id="pwd" />
      </div>
    </div>
	
    <div class="form-group">        
      <div class="col-sm-offset-2 col-sm-10">
        <button type="submit" name="change" class="btn btn-default">Change Password</button>
      </div>
    </div>
  </form>
  
  <?php
	if (isset($_POST['change']))
{
	//check fields
	$oldpassword=$_POST['oldpassword'];
	$newpassword=$_POST['newpassword'];
	$repeatnewpassword=$_POST['repeatnewpassword'];
	
	$queryget=$conn->query("SELECT password FROM users WHERE user_id=1") or die ("Query didnt work");
	$row=$queryget->fetch_assoc();
	
	$oldpassworddb=$row['password'];
	
	//check passwords
	if ($oldpassword==$oldpassworddb)
	{
		// check two new password
		if ($newpassword==$repeatnewpassword)
		{
			//change password in db
			
			$querychange=$conn->query("UPDATE users SET password='$newpassword' WHERE user_id=1");
			
			echo "<script>alert('Password Changed successfully!')</script>";
		}
		else
			echo "<script>alert('New Password dosnt Match!')</script>";
	
	}
	else
		echo "<script>alert('Old Password dosnt Match!')</script>";
}
	?>
  
      </div>
    </div>
</div>
  
</div>

<div class="container" style="margin-bottom: 10px; background-color:#808080; border-radius: 0 0 10px 10px; padding-left: 39px;">
  <div class="row" style="padding-top: 8px;">
	<div class="col-med-12 text-center">
		<p>© PTCL MANAGEMENT SYSTEM</p>
	</div>
  </div>
</div>

</body>
<html>

<?php } else echo nl2br("You must be logged in! \n click <a href='index.php'>here</a> to login"); ?>