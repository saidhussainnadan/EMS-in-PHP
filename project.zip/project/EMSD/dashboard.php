<?php session_start(); if(isset($_SESSION['username'])) { ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>PTCL MANAGEMENT SYSTEM</title>
<base href="">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/bootstrap-theme.min.css">
<link rel="stylesheet" href="css/style.css">

<script src="js/bootstrap.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.js"></script>

<style>
	.text-right a:hover {
		color:#fff !important;
	}
	
	.text-right a {
		font-size:12px; text-decoration: none; color: #000 !important;
	
	}
	
	.text-right {
		padding-top:45px;
	
	}
	
	
</style>

</head>

<body>

<div class="container" style="background-color:#808080; border-radius: 10px 10px 0 0; padding-left: 39px;">
  <div class="row">
	<div class="col-md-6">
		<h1>PTCL MANAGEMENT SYSTEM<h1>
	</div>
	
	<div class="col-md-6 text-right">
		<a href="attendance.php">Change Password</a> | <a href="logout.php">Logout</a>
	</div>
  </div>
</div>

<div class="container" style="background-color:#CCC;padding-top: 20px;">  
  <div class="row">
	<div class="col-md-4">
		<div class="list-group">
		  <a href="registration.php" class="list-group-item text-center" style="padding: 33px 0;">
			<h4 class="list-group-item-heading">Registration</h4>
		  </a>
		</div>
	</div>
	
	<div class="col-md-4">
		<div class="list-group">
		  <a href="section.php" class="list-group-item text-center" style="padding: 33px 0;">
			<h4 class="list-group-item-heading">Section</h4>
		  </a>
		</div>
	</div>
	
	<div class="col-md-4">
		<div class="list-group">
		  <a href="employees.php" class="list-group-item text-center" style="padding: 33px 0;">
			<h4 class="list-group-item-heading">Employee List</h4>
		  </a>
		</div>
	</div>
	
	<div class="col-md-4">
		<div class="list-group">
		  <a href="attendance.php" class="list-group-item text-center" style="padding: 33px 0;">
			<h4 class="list-group-item-heading">Attendance</h4>
		  </a>
		</div>
	</div>
  </div>
  
</div>

<div class="container" style="margin-bottom: 10px; background-color:#808080; border-radius: 0 0 10px 10px; padding-left: 39px;">
  <div class="row" style="padding-top: 8px;">
	<div class="col-med-12 text-center">
		<p>© PTCL MANAGEMENT SYSTEM</p>
	</div>
  </div>
</div>

</body>
<html>
<?php } else echo nl2br("You must be logged in! \n click <a href='index.php'>here</a> to login"); ?>