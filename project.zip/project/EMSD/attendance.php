<?php session_start(); if(isset($_SESSION['username'])) { ?>

<?php include("header.php") ?>
	
	<div class="col-sm-9 col-lg-10 ">
      <div class="col-md-12 text-justify">
		<h3>Attendance:</h3>
      </div>
	  
	  <table class="table">
  <tbody>
    <tr>
      <td>
		<form class="form-horizontal" method="post" action="">
	
	<div class="form-group">
      <label class="control-label col-sm-2">Name:</label>
      <div class="col-sm-6">
		<select name="emp_id" class="form-control">
			<option value="">--Select Name--</option>
				<?php 
					$sql="SELECT * FROM  emp_regist";
					$Q=$conn->query($sql);
					while($r=$Q->fetch_assoc()) {
			
				?>
			<option value="<?php echo $r['emp_regist_id']; ?>" ><?php echo $r['name']; ?></option>
		<?php } ?>
		</select>
      </div>
    </div>
	<div class="form-group">
      <label class="control-label col-sm-2" for="pwd">Date:</label>
      <div class="col-sm-6">          
        <input type="date" class="form-control" name="current_date">
      </div>
    </div>
    <div class="form-group">
	<label class="control-label col-sm-2" for="email"></label>
      <div class="col-sm-6">          
        <div class="radio">
		<label><input type="radio" value="Present" checked name="att">Present</label>
		</div>
		
		<div class="radio">
		<label><input type="radio" value="Leave" name="att">Leave</label>
		</div>
		
		<div class="radio">
		<label><input type="radio" value="Absent" name="att">Absent</label>
		</div>
      </div>
    </div>
	<div class="form-group">        
      <div class="col-sm-offset-2 col-sm-10">
        <button type="submit" name="submit" class="btn btn-default">Submit</button>
      </div>
    </div>
	</form>
	
	  <?php
		if(isset($_POST['submit'])) {
			$emp_id=$_POST['emp_id'];
			$att=$_POST['att'];
			$current_date=$_POST['current_date'];
			
			$que="insert into attendance (emp_regist_id,attendance,dat) values ('$emp_id','$att','$current_date')";
			if($conn->query($que)) {//$conn->query($que) mysql_query($que)
				echo "<script>alert('Successfuly Added')</script>";
				echo "<script>window.open('attendance.php','_self')</script>";
			}
		}
	?>
	
	  
	  </td>
    </tr>
  </tbody>
</table>	  
    </div>
</div>
  
</div>

<div class="container" style="margin-bottom: 10px; background-color:#808080; border-radius: 0 0 10px 10px; padding-left: 39px;">
  <div class="row" style="padding-top: 8px;">
	<div class="col-med-12 text-center">
		<p>© PTCL MANAGEMENT SYSTEM</p>
	</div>
  </div>
</div>

</body>
<html>

<?php } else echo nl2br("You must be logged in! \n click <a href='index.php'>here</a> to login"); ?>