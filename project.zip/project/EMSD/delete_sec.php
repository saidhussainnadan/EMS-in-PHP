<?php
include("db/db.php");

$id=$_GET['delete'];

$sql="DELETE FROM section WHERE sec_id='$id'";

$res=$conn->query($sql) or die ("not Deletd".mysql_error());

echo "<script>alert('Deleted Successfully!')</script>";
echo "<script>window.open('section.php','_self')</script>";

?>