<?php session_start(); if(isset($_SESSION['username'])) { ?>

<?php include("header.php") ?>

<?php

	if(isset($_GET['view_att'])) {
		$emp_id=$_GET['view_att'];
		$res=$conn->query("SELECT * FROM emp_regist WHERE emp_regist_id='$emp_id'");
		while($r=$res->fetch_assoc()) {
			$emp_name = $r['name'];
		}
		
	}	
?>

    <div class="col-sm-9 col-lg-10 ">
      <div class="col-md-12 text-justify">
		<h3><?php echo $emp_name; ?></h3>
      </div>
	  
	  <table class="table">
  <thead>
    <tr>
      <th width="20%">Date</th>
	  <th width="23%">Attendance</th>
    </tr>

  </thead>
  <tbody>
  <?php
		$sql="SELECT * FROM  `attendance` WHERE emp_regist_id='$emp_id'";
		$Q=$conn->query($sql);
		if($Q->num_rows > 0) {
		while($r=$Q->fetch_assoc()) {
	?>
    <tr>
      <td><?php echo $r['dat']; ?></td>
	  <td><?php echo $r['attendance']; ?></td>
	  <td></td>
    </tr>
		<?php } } else { ?>
		
	<tr>
	  <td>Record not found</td>
    </tr>
	<?php }  ?>
  </tbody>
</table>
	  
    </div>
</div>
  
</div>

<div class="container" style="margin-bottom: 10px; background-color:#808080; border-radius: 0 0 10px 10px; padding-left: 39px;">
  <div class="row" style="padding-top: 8px;">
	<div class="col-med-12 text-center">
		<p>© PTCL MANAGEMENT SYSTEM</p>
	</div>
  </div>
</div>

</body>
<html>
<?php } else echo nl2br("You must be logged in! \n click <a href='index.php'>here</a> to login"); ?>