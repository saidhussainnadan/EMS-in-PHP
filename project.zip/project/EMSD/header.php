<?php include('db/db.php'); ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>PTCL MANAGEMENT SYSTEM</title>
<base href="">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/bootstrap-theme.min.css">
<link rel="stylesheet" href="css/style.css">

<script src="js/bootstrap.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.js"></script>

<style>
	.text-right a:hover {
		color:#fff !important;
	}
	
	.text-right a {
		font-size:12px; text-decoration: none; color: #000 !important;
	
	}
	
	.text-right {
		padding-top:45px;
	
	}
	
</style>
</head>

<body>

<div class="container" style="background-color:#808080; border-radius: 10px 10px 0 0; padding-left: 39px;">
  <div class="row">
	<div class="col-md-6">
		<h1>PTCL MANAGEMENT SYSTEM<h1>
	</div>
	
	<div class="col-md-6 text-right">
		<a href="change-password.php">Change Password</a> | <a href="logout.php">Logout</a>
	</div>
  </div>
</div>

<div class="container" style="background-color:#CCC;padding-top: 20px;">  
  <div class="row">
    <div class="col-sm-3 col-lg-2" style="background-color:#808080">
      <nav class="navbar fixed-side">
        <div class="navbar">
          <ul>
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="section.php">Section</a></li>
            <li><a href="registration.php">Registration</a></li>
            <li><a href="employees.php">Employee List</a></li>
			<li><a href="attendance.php">Attendance</a></li>
          </ul>
        </div>
      </nav>
    </div>