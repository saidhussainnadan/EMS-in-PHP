<?php session_start(); if(isset($_SESSION['username'])) { ?>

<?php include("header.php") ?>

    <div class="col-sm-9 col-lg-10 ">
      <div class="col-md-12 text-justify">
		<h3>Employee List:</h3>
      </div>
	  
	  <table class="table">
  <thead>
    <tr>
      <th width="20%">Name</th>
	  <th width="23%">CNIC#</th>
      <th width="35%">Action</th>
	  <th width="22%"><a href="registration.php" class="btn btn-sm btn-success">Add Employee</a></th>
    </tr>

  </thead>
  <tbody>
  <?php
    $sql="SELECT * FROM  emp_regist";
    
    $Q=$conn->query($sql);
    if($Q->num_rows > 0){
		while($r=$Q->fetch_assoc()) {
	?>
    <tr>
      <td><?php echo $r['name']; ?></td>
	  <td><?php echo $r['cnic']; ?></td>
      <td>
		<a href="edit_reg.php?edit=<?php echo $r['emp_regist_id']; ?>" class="btn btn-xs btn-primary">Edit</a>
		<a href="view-emp.php?view=<?php echo $r['emp_regist_id']; ?>" class="btn btn-xs btn-success">View Detail</a>
		<a href="view-att.php?view_att=<?php echo $r['emp_regist_id']; ?>" class="btn btn-xs btn-success">Attendance Detail</a>
		<a href="delete_emp.php?delete=<?php echo $r['emp_regist_id']; ?>" onclick="return confirm('Are you sure you want to Delete?');" class="btn btn-xs btn-danger">Delete</a>
	  </td>
	  <td></td>
    </tr>
	<?php }} ?>
	
  </tbody>
</table>
	  
    </div>
</div>
  
</div>

<div class="container" style="margin-bottom: 10px; background-color:#808080; border-radius: 0 0 10px 10px; padding-left: 39px;">
  <div class="row" style="padding-top: 8px;">
	<div class="col-med-12 text-center">
		<p>© PTCL MANAGEMENT SYSTEM</p>
	</div>
  </div>
</div>

</body>
<html>

<?php } else echo nl2br("You must be logged in! \n click <a href='index.php'>here</a> to login"); ?>