<?php session_start(); if(isset($_SESSION['username'])) { ?>

<?php include("header.php") ?>

    <div class="col-sm-9 col-lg-10 ">
      <div class="col-md-12 text-justify">
	  <h3>Section:</h3>
      	<form class="form-horizontal" method="post" action="">
	<div class="form-group">
      <label class="control-label col-sm-2" for="email">Section Name:</label>
      <div class="col-sm-4">
        <input type="text" class="form-control" required name="sec_name" />
      </div>
	  <button type="submit" name="submit" class="btn btn-default">Add</button>
    </div>
	
  </form>
  
  
  <?php

	if(isset($_POST['submit'])) {
		$sec_name=$_POST['sec_name'];
		
		$que="insert into section (sec_name) values ('$sec_name')";
		if($conn->query($que)) {
			echo "<script>alert('Successfuly Added')</script>";
		}
	}
	
	
	
	
?>
      </div>
	  
	  <table class="table">
  <thead>
    <tr>
      <th>Section Name</th>
      <th>Action</th>
    </tr>
  </thead>
  <tbody>
  
  <?php
	$sql="SELECT * FROM  `section` Where 1";
	$Q=$conn->query($sql);							
	while($r=$Q->fetch_assoc()) {
?>
  
    <tr>
      <td><?php echo $r['sec_name']; ?></td>
      <td>
		<a href="edit_section.php?edit=<?php echo $r['sec_id']; ?>" class="btn btn-xs btn-primary">Edit</a> 
		<a href="delete_sec.php?delete=<?php echo $r['sec_id']; ?>" onclick="return confirm('Are you sure you want to Delete?');" class="btn btn-xs btn-danger">Delete</a>
	</td>
    </tr>
	<?php
		}
	?>

  </tbody>
</table>
	  
    </div>
</div>
  
</div>

<div class="container" style="margin-bottom: 10px; background-color:#808080; border-radius: 0 0 10px 10px; padding-left: 39px;">
  <div class="row" style="padding-top: 8px;">
	<div class="col-med-12 text-center">
		<p>© PTCL MANAGEMENT SYSTEM</p>
	</div>
  </div>
</div>

</body>
<html>

<?php } else echo nl2br("You must be logged in! \n click <a href='index.php'>here</a> to login"); ?>