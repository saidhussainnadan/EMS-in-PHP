<?php session_start(); if(isset($_SESSION['username'])) { ?>

<?php include("header.php") ?>
    <div class="col-sm-9 col-lg-10 ">
      <div class="col-md-12 text-justify">
	  <h3>Registration:</h3>
	  
	<?php
	
		if(isset($_GET['edit'])) {
			$id=$_GET['edit'];
			$res=$conn->query("SELECT * FROM emp_regist WHERE emp_regist_id='$id'");
			$row=$res->fetch_array();
		}
	?>
	  
      	<form class="form-horizontal" method="post" action="">
	<div class="form-group">
      <label class="control-label col-sm-2" for="email">Name:</label>
      <div class="col-sm-6">
        <input type="text" class="form-control" id="email" name="emp_name" value="<?php echo $row['name'] ?>" />
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="pwd">F/Name:</label>
      <div class="col-sm-6">          
        <input type="text" class="form-control" id="pwd" name="fname" value="<?php echo $row['fname'] ?>" />
      </div>
    </div>
	<div class="form-group">
      <label class="control-label col-sm-2" for="pwd">CNIC:</label>
      <div class="col-sm-6">          
        <input type="text" class="form-control" id="pwd" name="cnic" value="<?php echo $row['cnic'] ?>" />
      </div>
    </div>
	<div class="form-group">
      <label class="control-label col-sm-2" for="pwd">Gender:</label>
      <div class="col-sm-6">
		<select name="gender" class="form-control">
			<option value="">--Gender--</option>
			<?php if($row['gender'] == 'Male') { $gen = ($row['gender'] == 'Male') ? "selected = 'selected'" : ""; ?>
			<option value="Male" <?php echo $gen?>>Male</option>
			  <?php } else { ?>
				<option value="Male">Male</option>
			 <?php } ?>
			
			<?php  if($row['gender'] == 'Female') { $gen = ($row['gender'] == 'Female') ? "selected = 'selected'" : ""; ?>
				<option value="Male" <?php echo $gen?>>Female</option>
				
			<?php } else { ?>
				<option value="Female">Female</option>
			 <?php } ?>
		</select>
      </div>
    </div>
	<div class="form-group">
      <label class="control-label col-sm-2" for="pwd">Designation:</label>
      <div class="col-sm-6">          
        <input type="text" class="form-control" id="pwd" name="designation" value="<?php echo $row['designation'] ?>" />
      </div>
    </div>
	<div class="form-group">
      <label class="control-label col-sm-2" for="pwd">Section:</label>
      <div class="col-sm-6">
		<select name="section" class="form-control">
			<option value="">--Select--</option>
		<?php 
			$sql="SELECT * FROM  `section` Where 1";
			$Q=$conn->query($sql);
			while($r=$Q->fetch_assoc()) {
				$s = ($r['sec_id'] == $row['section']) ? "selected='selected'" : "";
		
		?>
			<option value="<?php echo $r['sec_id']; ?>"<?php echo $s; ?> ><?php echo $r['sec_name']; ?></option>
		<?php } ?>
			
		</select>
      </div>
    </div>
	<div class="form-group">
      <label class="control-label col-sm-2" for="pwd">Mobile:</label>
      <div class="col-sm-6">          
        <input type="text" class="form-control" id="pwd" name="mobile" value="<?php echo $row['mobile'] ?>" />
      </div>
    </div>
	<div class="form-group">
      <label class="control-label col-sm-2" for="pwd">Date of Entry:</label>
      <div class="col-sm-6">          
        <input type="date" class="form-control" id="pwd" name="dat" value="<?php echo $row['entry_date'] ?>" />
      </div>
    </div>
	<div class="form-group">
      <label class="control-label col-sm-2" for="pwd">Address:</label>
      <div class="col-sm-6">          
        <textarea class="form-control" name="address"><?php echo $row['address'] ?></textarea>
      </div>
    </div>
    <div class="form-group">        
      <div class="col-sm-offset-2 col-sm-10">
        <button type="submit" name="submit" class="btn btn-default">Submit</button>
      </div>
    </div>
  </form>
  
	<?php
		if(isset($_POST['submit'])) {
			$name=$_POST['emp_name'];
			$fname=$_POST['fname'];
			$cnic=$_POST['cnic'];
			$gender=$_POST['gender'];
			$designation=$_POST['designation'];
			$section=$_POST['section'];
			$mobile=$_POST['mobile'];
			$dat=$_POST['dat'];
			$address=$_POST['address'];
			
			$sql="UPDATE emp_regist SET name='$name',fname='$fname',cnic='$cnic',gender='$gender',designation='$designation',section='$section',mobile='$mobile',entry_date='$dat',address='$address' WHERE emp_regist_id='$id'";

			$res=$conn->query($sql) or die ("not update".mysql_error());
			echo "<script>alert('Updated Successfully')</script>";
			echo "<script>window.open('employees.php','_self')</script>";
		}
	?>
  
      </div>
    </div>
</div>
  
</div>

<div class="container" style="margin-bottom: 10px; background-color:#808080; border-radius: 0 0 10px 10px; padding-left: 39px;">
  <div class="row" style="padding-top: 8px;">
	<div class="col-med-12 text-center">
		<p>© PTCL MANAGEMENT SYSTEM</p>
	</div>
  </div>
</div>

</body>
<html>

<?php } else echo nl2br("You must be logged in! \n click <a href='index.php'>here</a> to login"); ?>